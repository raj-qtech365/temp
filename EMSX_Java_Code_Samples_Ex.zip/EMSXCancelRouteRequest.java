/* Copyright 2013. Bloomberg Finance L.P.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:  The above
 * copyright notice and this permission notice shall be included in all copies
 * or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
package com.bloomberg.samples;

import com.bloomberglp.blpapi.Event;
import com.bloomberglp.blpapi.Message;
import com.bloomberglp.blpapi.MessageIterator;
import com.bloomberglp.blpapi.Name;
import com.bloomberglp.blpapi.Session;
import com.bloomberglp.blpapi.SessionOptions;
import com.bloomberglp.blpapi.Request;
import com.bloomberglp.blpapi.Service;
import com.bloomberglp.blpapi.Element;
import com.bloomberglp.blpapi.CorrelationID;

public class EMSXCancelRouteRequest {
	
	/* Compile with:-
	 *     javac -cp c:\blp\API\APIv3\JavaAPI\v3.5.1.1\lib\blpapi3.jar com\bloomberg\samples\EMSXCancelRouteRequest.java
	 *     
	 * Run with:-
	 *     java -cp .;c:\blp\API\APIv3\JavaAPI\v3.5.1.1\lib\blpapi3.jar com.bloomberg.samples.EMSXCancelRouteRequest <Sequence No.> <Route ID>
	 */
	
    private static final Name ERROR_INFO = new Name("ErrorInfo");
    private static final Name CANCEL_ROUTE = new Name("CancelRoute");
    
	private String 	d_service;
    private String  d_host;
    private int     d_port;
    
    private Integer		sequenceNumber;
    private Integer		routeID;
    private Integer		traderUUID;
    
    private CorrelationID requestID;
    
    public static void main(String[] args) throws java.lang.Exception
    {
        System.out.println("Bloomberg - EMSX API Example - EMSXCancelRouteRequest");

        EMSXCancelRouteRequest example = new EMSXCancelRouteRequest();
        example.run(args);

        // This sample program will terminate once it has received confirmation that the request
        // has been processed.
    }
    
    public EMSXCancelRouteRequest()
    {
    	
    	// Define the service required, in this case the beta service, 
    	// and the values to be used by the SessionOptions object
    	// to identify ip/port of the backend process.
    	
    	d_service = "//blp/emapisvc_beta";
    	d_host = "localhost";
        d_port = 8194;

    }

    private void run(String[] args) throws Exception
    {

    	if (!parseCommandLine(args)) return;
    	
    	SessionOptions d_sessionOptions = new SessionOptions();
        d_sessionOptions.setServerHost(d_host);
        d_sessionOptions.setServerPort(d_port);

        Session session = new Session(d_sessionOptions);
        
        if(!session.start()) {
        	System.err.println("Error: failed to start session.");
        	return;
        }
        
        System.out.println("Session started...");
        
        if(!session.openService(d_service)) {
        	session.stop();
        	System.err.println("Error: failed to open service.");
        	return;
        }
        
        Service service = session.getService(d_service);
        System.out.println("Service opened...");

        // Create a CancelRoute request and populate it with the order number and route ID
        Request request = service.createRequest("CancelRoute");
        Element routes = request.getElement("ROUTES"); //Note, the case is important.
        Element route = routes.appendElement();
        route.getElement("EMSX_SEQUENCE").setValue(sequenceNumber);
        route.getElement("EMSX_ROUTE_ID").setValue(routeID);

        if(traderUUID>0) request.set("EMSX_TRADER_UUID",traderUUID);
        
        requestID = new CorrelationID(1);
        
        // Submit the request
        session.sendRequest(request, requestID);

    	int timeoutInMilliSeconds = 5000; 

    	Event evt = session.nextEvent(timeoutInMilliSeconds);
    	do
    	{

    		System.out.println("Received Event: " + evt.eventType().toString());
            
            MessageIterator msgIter = evt.messageIterator();
            
            while(msgIter.hasNext())
            {
            	Message msg = msgIter.next();
                System.out.println(msg.toString());
                
                if(evt.eventType()==Event.EventType.RESPONSE && msg.correlationID()==requestID) {
 
                	System.out.println("Message Type: " + msg.messageType());
                	if(msg.messageType().equals(ERROR_INFO)) {
                		Integer errorCode = msg.getElementAsInt32("ERROR_CODE");
                		String errorMessage = msg.getElementAsString("ERROR_MESSAGE");
                		System.out.println("ERROR CODE: " + errorCode + "\tERROR MESSAGE: " + errorMessage);
                	} else if(msg.messageType().equals(CANCEL_ROUTE)) {
                		Integer status = msg.getElementAsInt32("STATUS");
                		String message = msg.getElementAsString("MESSAGE");
                		System.out.println("STATUS: " + status+ "\tMESSAGE: " + message);
                	}
                	session.stop();
                	return;
                }
            }
    		
    		evt = session.nextEvent(timeoutInMilliSeconds);

    	} while (evt.eventType() != Event.EventType.TIMEOUT);
    	
    	session.stop();
    }

	private boolean parseCommandLine(String[] args)
    {
		if(args.length < 2 ) {
			printUsage();
			return false;
		} else {
			
			sequenceNumber = Integer.parseInt(args[0]);
			routeID = Integer.parseInt(args[1]);
			
			if(args.length>2) traderUUID = Integer.parseInt(args[2]);
			
			System.out.println("Sequence No.: " + sequenceNumber.toString() + "\tRoute ID: " + routeID.toString() + "\tTrader UUID: " + traderUUID.toString());
		}
		return true;
    }

    private void printUsage()
	{
		System.out.println("Usage:");
	    System.out.println("	EMSXCancelRouteRequest <Sequence No.> <Route ID> [<Trader UUID>]");
	}
	
}

