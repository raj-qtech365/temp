/* Copyright 2013. Bloomberg Finance L.P.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:  The above
 * copyright notice and this permission notice shall be included in all copies
 * or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
package com.bloomberg.samples;

import com.bloomberglp.blpapi.Event;
import com.bloomberglp.blpapi.Message;
import com.bloomberglp.blpapi.MessageIterator;
import com.bloomberglp.blpapi.Name;
import com.bloomberglp.blpapi.Session;
import com.bloomberglp.blpapi.SessionOptions;
import com.bloomberglp.blpapi.Request;
import com.bloomberglp.blpapi.Service;
import com.bloomberglp.blpapi.CorrelationID;

public class EMSXCreateOrderAndRouteManuallyRequest {

	/* Compile with:-
	 *     javac -cp c:\blp\API\APIv3\JavaAPI\v3.5.1.1\lib\blpapi3.jar com\bloomberg\samples\EMSXCreateOrderAndRouteManuallyRequest.java
	 *     
	 * Run with:-
	 *     java -cp .;c:\blp\API\APIv3\JavaAPI\v3.5.1.1\lib\blpapi3.jar 
	 *         com.bloomberg.samples.EMSXCreateOrderAndRouteManuallyRequest 
	 *         EMSX_SIDE=BUY EMSX_AMOUNT=1000 EMSX_TICKER="IBM US Equity" EMSX_ORDER_TYPE=MKT
	 *   	   EMSX_HAND_INSTRUCTION="ANY" EMSX_TIF=DAY EMSX_BROKER=BB
	 */

    private static final Name ERROR_INFO = new Name("ErrorInfo");
    private static final Name CREATE_ORDER_AND_ROUTE_MANUALLY = new Name("CreateOrderAndRouteManually");
    
	private String 	d_service;
    private String  d_host;
    private int     d_port;
    
    private CorrelationID requestID;
    
    private	String	emsx_side = "";
    private String	emsx_amount = "";
    private String	emsx_ticker = "";
    private String 	emsx_order_type = "";
    private String 	emsx_hand_instruction = "";
    private String 	emsx_tif = "";
    private String 	emsx_account = "";
    private String 	emsx_broker = "";
    private String 	emsx_cfd_flag = "";
    private String 	emsx_clearing_account = "";
    private String 	emsx_clearing_firm = "";
    private String 	emsx_exchange_destination = "";
    private	String	emsx_exec_instructions = "";
    private	String	emsx_get_warnings = "";
    private	String	emsx_gtd_date = "";
    private	String	emsx_limit_price = "";
    private	String	emsx_locate_broker = "";
    private	String	emsx_locate_id = "";
    private	String	emsx_locate_req = "";
    private	String	emsx_notes = "";
    private	String	emsx_odd_lot = "";
    private	String	emsx_order_origin = "";
    private	String	emsx_p_a = "";
    private	String	emsx_release_time = "";
    private	String	emsx_settle_date = "";
    private	String	emsx_stop_price = "";


    
    public static void main(String[] args) throws java.lang.Exception
    {
        System.out.println("Bloomberg - EMSX API Example - EMSXCreateOrderAndRouteManuallyRequest\n");

        EMSXCreateOrderAndRouteManuallyRequest example = new EMSXCreateOrderAndRouteManuallyRequest();
        example.run(args);

        // This sample program will terminate once it has received confirmation that the request
        // has been processed.
    }
    
    public EMSXCreateOrderAndRouteManuallyRequest()
    {
    	
    	// Define the service required, in this case the beta service, 
    	// and the values to be used by the SessionOptions object
    	// to identify ip/port of the backend process.
    	
    	d_service = "//blp/emapisvc_beta";
    	d_host = "localhost";
        d_port = 8194;

    }

    private void run(String[] args) throws Exception
    {

    	if (!parseCommandLine(args)) return;
    	
    	SessionOptions d_sessionOptions = new SessionOptions();
        d_sessionOptions.setServerHost(d_host);
        d_sessionOptions.setServerPort(d_port);

        Session session = new Session(d_sessionOptions);
        
        if(!session.start()) {
        	System.err.println("Error: failed to start session.");
        	return;
        }
        
        System.out.println("Session started...");
        
        if(!session.openService(d_service)) {
        	session.stop();
        	System.err.println("Error: failed to open service.");
        	return;
        }
        
        Service service = session.getService(d_service);
        System.out.println("Service opened...");
        
        
	    Request request = service.createRequest("CreateOrderAndRouteManually");

	    request.set("EMSX_TICKER", emsx_ticker);
	    request.set("EMSX_AMOUNT", Integer.parseInt(emsx_amount));
	    request.set("EMSX_ORDER_TYPE", emsx_order_type);
	    request.set("EMSX_BROKER", emsx_broker);
	    request.set("EMSX_TIF", emsx_tif);
	    request.set("EMSX_HAND_INSTRUCTION", emsx_hand_instruction);
	    request.set("EMSX_SIDE", emsx_side);
	    request.set("EMSX_BROKER", emsx_broker);
	
	    if (emsx_account.length() > 0) 					request.set("EMSX_ACCOUNT",emsx_account);
	    if (emsx_limit_price.length() > 0 ) 			request.set("EMSX_LIMIT_PRICE", Double.parseDouble(emsx_limit_price));
	    if (emsx_cfd_flag.length() > 0 )				request.set("EMSX_CFD_FLAG", emsx_cfd_flag);
	    if (emsx_clearing_account.length() > 0 )		request.set("EMSX_CLEARING_ACCOUNT", emsx_clearing_account);
	    if (emsx_clearing_firm.length() > 0 )			request.set("EMSX_CLEARING_FIRM", emsx_clearing_firm);
	    if (emsx_exchange_destination.length() > 0 )	request.set("EMSX_EXCHANGE_DESTINATION", emsx_exchange_destination);
	    if (emsx_exec_instructions.length() > 0 )	 	request.set("EMSX_EXEC_INSTRUCTIONS", emsx_exec_instructions);
	    if (emsx_get_warnings.length() > 0 )	 		request.set("EMSX_GET_WARNINGS", emsx_get_warnings);
	    if (emsx_gtd_date.length() > 0 )	 			request.set("EMSX_GTD_DATE", emsx_gtd_date);
	    if (emsx_locate_broker.length() > 0 )	 		request.set("EMSX_LOCATE_BROKER", emsx_locate_broker);
	    if (emsx_locate_id.length() > 0 )	 			request.set("EMSX_LOCATE_ID", emsx_locate_id);
	    if (emsx_locate_req.length() > 0 )	 			request.set("EMSX_LOCATE_REQ", emsx_locate_req);
	    if (emsx_notes.length() > 0 )	 				request.set("EMSX_NOTES", emsx_notes);
	    if (emsx_odd_lot.length() > 0 )	 				request.set("EMSX_ODD_LOT", emsx_odd_lot);
	    if (emsx_order_origin.length() > 0 )	 		request.set("EMSX_ORDER_ORIGIN", emsx_order_origin);
	    if (emsx_p_a.length() > 0 )	 					request.set("EMSX_P_A", emsx_p_a);
	    if (emsx_release_time.length() > 0 )	 		request.set("EMSX_RELEASE_TIME", emsx_release_time);
	    if (emsx_settle_date.length() > 0 )	 			request.set("EMSX_SETTLE_DATE", emsx_settle_date);
	    if (emsx_stop_price.length() > 0 )	 			request.set("EMSX_STOP_PRICE", emsx_stop_price);

	    // Submit the request
	    
	    System.out.println("Request: " + request.toString());

        requestID = new CorrelationID(1);
        
        // Submit the request
        session.sendRequest(request, requestID);

    	int timeoutInMilliSeconds = 5000; 

    	Event evt = session.nextEvent(timeoutInMilliSeconds);
    	do
    	{

    		System.out.println("Received Event: " + evt.eventType().toString());
            
            MessageIterator msgIter = evt.messageIterator();
            
            while(msgIter.hasNext())
            {
            	Message msg = msgIter.next();
                System.out.println(msg.toString());
                
                if(evt.eventType()==Event.EventType.RESPONSE && msg.correlationID()==requestID) {
                	
                	System.out.println("Message Type: " + msg.messageType());
                	if(msg.messageType().equals(ERROR_INFO)) {
                		Integer errorCode = msg.getElementAsInt32("ERROR_CODE");
                		String errorMessage = msg.getElementAsString("ERROR_MESSAGE");
                		System.out.println("ERROR CODE: " + errorCode + "\tERROR MESSAGE: " + errorMessage);
                	} else if(msg.messageType().equals(CREATE_ORDER_AND_ROUTE_MANUALLY)) {
                		Integer emsx_sequence = msg.getElementAsInt32("EMSX_SEQUENCE");
                		Integer emsx_route_id = msg.getElementAsInt32("EMSX_ROUTE_ID");
                		String message = msg.getElementAsString("MESSAGE");
                		System.out.println("EMSX_SEQUENCE: " + emsx_sequence + "\tEMSX_ROUTE_ID: " + emsx_route_id + "\tMESSAGE: " + message);
                	}
                	
                	session.stop();
                	return;
                }
            }
    		
    		evt = session.nextEvent(timeoutInMilliSeconds);

    		
    	} while (evt.eventType() != Event.EventType.TIMEOUT);
    	
    	session.stop();
    }

	private boolean parseCommandLine(String[] args)
    {
		if(args.length < 6 ) {
			System.out.println("Error: Missing required parameters\n");
			printUsage();
			return false;
		} else {
			for(int i=0; i<args.length;i++) {
				if(isArg(args[i],"EMSX_SIDE")) emsx_side=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_AMOUNT")) emsx_amount=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_TICKER")) emsx_ticker=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_ORDER_TYPE")) emsx_order_type=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_HAND_INSTRUCTION")) emsx_hand_instruction=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_TIF")) emsx_tif=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_ACCOUNT")) emsx_account=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_BROKER")) emsx_broker=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_CFD_FLAG")) emsx_cfd_flag=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_CLEARING_ACCOUNT")) emsx_clearing_account=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_CLEARING_FIRM")) emsx_clearing_firm=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_EXCHANGE_DESTINATION")) emsx_exchange_destination=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_EXEC_INSTRUCTIONS")) emsx_exec_instructions=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_GET_WARNINGS")) emsx_get_warnings=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_GTD_DATE")) emsx_gtd_date=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_LIMIT_PRICE")) emsx_limit_price=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_LOCATE_BROKER")) emsx_locate_broker=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_LOCATE_ID")) emsx_locate_id=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_LOCATE_REQ")) emsx_locate_req=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_NOTES")) emsx_notes=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_ODD_LOT")) emsx_odd_lot=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_ORDER_ORIGIN")) emsx_order_origin=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_P_A")) emsx_p_a=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_RELEASE_TIME")) emsx_release_time=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_SETTLE_DATE")) emsx_settle_date=getArgValue(args[i]);
				else if(isArg(args[i],"EMSX_STOP_PRICE")) emsx_stop_price=getArgValue(args[i]);
				else System.out.println("Warning>> Unknown parameter:" + args[i]);
			}

			showParameters();
		}
		return true;
    }
	
	private void showParameters() {
		System.out.println("Parameter List:-");
		System.out.println("EMSX_SIDE: " + emsx_side);
		System.out.println("EMSX_AMOUNT: " + emsx_amount);
		System.out.println("EMSX_TICKER: " + emsx_ticker);
		System.out.println("EMSX_ORDER_TYPE: " + emsx_order_type);
		System.out.println("EMSX_HAND_INSTRUCTION: " + emsx_hand_instruction);
		System.out.println("EMSX_TIF: " + emsx_tif);
		System.out.println("EMSX_ACCOUNT: " + emsx_account);
		System.out.println("EMSX_BROKER: " + emsx_broker);
		System.out.println("EMSX_CFD_FLAG: " + emsx_cfd_flag);
		System.out.println("EMSX_CLEARING_ACCOUNT: " + emsx_clearing_account);
		System.out.println("EMSX_CLEARING_FIRM: " + emsx_clearing_firm);
		System.out.println("EMSX_EXCHANGE_DESTINATION: " + emsx_exchange_destination);
		System.out.println("EMSX_EXEC_INSTRUCTIONS: " + emsx_exec_instructions);
		System.out.println("EMSX_GET_WARNINGS: " + emsx_get_warnings);
		System.out.println("EMSX_GTD_DATE: " + emsx_gtd_date);
		System.out.println("EMSX_LIMIT_PRICE: " + emsx_limit_price);
		System.out.println("EMSX_LOCATE_BROKER: " + emsx_locate_broker);
		System.out.println("EMSX_LOCATE_ID: " + emsx_locate_id);
		System.out.println("EMSX_LOCATE_REQ: " + emsx_locate_req);
		System.out.println("EMSX_NOTES: " + emsx_notes);
		System.out.println("EMSX_ODD_LOT: " + emsx_odd_lot);
		System.out.println("EMSX_ORDER_ORIGIN: " + emsx_order_origin);
		System.out.println("EMSX_P_A: " + emsx_p_a);
		System.out.println("EMSX_RELEASE_TIME: " + emsx_release_time);
		System.out.println("EMSX_SETTLE_DATE: " + emsx_settle_date);
		System.out.println("EMSX_STOP_PRICE: " + emsx_stop_price);
		
	}

	private boolean isArg(String arg, String find) 
	{
		if(arg.indexOf(find)>=0) return true;
		else return false;
	}
	
	private String getArgValue(String arg)
	{
		return (arg.substring(arg.indexOf("=")+1));
	}

    private void printUsage()
	{
		System.out.println("Usage:");
	    System.out.println("EMSXCreateOrderAndRouteManuallyRequest EMSX_SIDE=<value> EMSX_AMOUNT=<value> EMSX_TICKER=\"<value>\" EMSX_ORDER_TYPE=<value>");
	    System.out.println("                                       EMSX_HAND_INSTRUCTION=\"<value>\" EMSX_TIF=<value> EMSX_BROKER=<value>");
	    System.out.println("                                      [EMSX_ACCOUNT=<value>] [EMSX_CFD_FLAG=<value>] [EMSX_CLEARING_ACCOUNT=<value>]");
	    System.out.println("                                      [EMSX_CLEARING_FIRM=\"<value>\"] [EMSX_EXCHANGE_DESTINATION=<value>] [EMSX_EXEC_INSTRUCTIONS=\"<value>\"]");
	    System.out.println("                                      [EMSX_GET_WARNINGS=<value>] [EMSX_GTD_DATE=<MMDDYYYY>] [EMSX_LIMIT_PRICE=<value>]");
	    System.out.println("                                      [EMSX_LOCATE_BROKER=<value>] [EMSX_LOCATE_ID=<value>] [EMSX_LOCATE_REQ=<value>] [EMSX_NOTES=\"<value>\"]");
	    System.out.println("                                      [EMSX_ODD_LOT=<value>] [EMSX_ORDER_ORIGIN=<value>] [EMSX_P_A=<value>] [EMSX_RELEASE_TIME=<value>]");
	    System.out.println("                                      [EMSX_SETTLE_DATE=<MMDDYYYY>] [EMSX_STOP_PRICE=<value>]\n");

	}
	
}

