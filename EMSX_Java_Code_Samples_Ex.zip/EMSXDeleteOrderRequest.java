/* Copyright 2013. Bloomberg Finance L.P.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:  The above
 * copyright notice and this permission notice shall be included in all copies
 * or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
package com.bloomberg.samples;

import java.util.ArrayList;

import com.bloomberglp.blpapi.Event;
import com.bloomberglp.blpapi.Message;
import com.bloomberglp.blpapi.MessageIterator;
import com.bloomberglp.blpapi.Name;
import com.bloomberglp.blpapi.Session;
import com.bloomberglp.blpapi.SessionOptions;
import com.bloomberglp.blpapi.Request;
import com.bloomberglp.blpapi.Service;
import com.bloomberglp.blpapi.CorrelationID;

public class EMSXDeleteOrderRequest {
	
	/* Compile with:-
	 *     javac -cp c:\blp\API\APIv3\JavaAPI\v3.5.1.1\lib\blpapi3.jar com\bloomberg\samples\EMSXDeleteOrderRequest.java
	 *     
	 * Run with:-
	 *     java -cp .;c:\blp\API\APIv3\JavaAPI\v3.5.1.1\lib\blpapi3.jar 
	 *         com.bloomberg.samples.EMSXDeleteOrderRequest 1359434 1359455
	 */

    private static final Name 	ERROR_INFO = new Name("ErrorInfo");
    private static final Name 	DELETE_ORDER = new Name("DeleteOrder");

	private String 	d_service;
    private String  d_host;
    private int     d_port;
    
    private ArrayList<Integer>	sequenceNumbers = new ArrayList<Integer>();
    
    private CorrelationID requestID;
    
    public static void main(String[] args) throws java.lang.Exception
    {
        System.out.println("Bloomberg - EMSX API Example - EMSXDeleteOrderRequest");

        EMSXDeleteOrderRequest example = new EMSXDeleteOrderRequest();
        example.run(args);

        // This sample program will terminate once it has received confirmation that the request
        // has been processed.
    }
    
    public EMSXDeleteOrderRequest()
    {
    	
    	// Define the service required, in this case the beta service, 
    	// and the values to be used by the SessionOptions object
    	// to identify IP/port of the back-end process.
    	
    	d_service = "//blp/emapisvc_beta";
    	d_host = "localhost";
        d_port = 8194;

    }

    private void run(String[] args) throws Exception
    {

    	if (!parseCommandLine(args)) return;
    	
    	SessionOptions d_sessionOptions = new SessionOptions();
        d_sessionOptions.setServerHost(d_host);
        d_sessionOptions.setServerPort(d_port);

        Session session = new Session(d_sessionOptions);
        
        if(!session.start()) {
        	System.err.println("Error: failed to start session.");
        	return;
        }
        
        System.out.println("Session started...");
        
        if(!session.openService(d_service)) {
        	session.stop();
        	System.err.println("Error: failed to open service.");
        	return;
        }
        
        Service service = session.getService(d_service);
        System.out.println("Service opened...");

        // Create a DeleteOrder request and populate it with the order number
        Request request = service.createRequest("DeleteOrder");
        
        for(Integer i:sequenceNumbers)
            request.getElement("EMSX_SEQUENCE").appendValue(i);
        
        requestID = new CorrelationID(1);
        
        // Submit the request
        System.out.println("Submitting request...");
        session.sendRequest(request, requestID);

    	int timeoutInMilliSeconds = 5000; 

    	Event evt = session.nextEvent(timeoutInMilliSeconds);
    	do
    	{

    		System.out.println("Received Event: " + evt.eventType().toString());
            
            MessageIterator msgIter = evt.messageIterator();
            
            while(msgIter.hasNext())
            {
            	Message msg = msgIter.next();
                System.out.println(msg.toString());
                
                if(evt.eventType()==Event.EventType.RESPONSE && msg.correlationID()==requestID) {
                	
                	System.out.println("Message Type: " + msg.messageType());
                	if(msg.messageType().equals(ERROR_INFO)) {
                		Integer errorCode = msg.getElementAsInt32("ERROR_CODE");
                		String errorMessage = msg.getElementAsString("ERROR_MESSAGE");
                		System.out.println("ERROR CODE: " + errorCode + "\tERROR MESSAGE: " + errorMessage);
                	} else if(msg.messageType().equals(DELETE_ORDER)) {
                		Integer status = msg.getElementAsInt32("STATUS");
                		String message = msg.getElementAsString("MESSAGE");
                		System.out.println("STATUS: " + status+ "\tMESSAGE: " + message);                	
                	}
                	                	
                	session.stop();
                	return;
                }
            }
    		
    		evt = session.nextEvent(timeoutInMilliSeconds);

    	} while (evt.eventType() != Event.EventType.TIMEOUT);
    	
    	session.stop();
    }

	private boolean parseCommandLine(String[] args)
    {
		if(args.length < 1 ) {
			printUsage();
			return false;
		} else {
			for(int i=0; i<args.length;i++) {
				sequenceNumbers.add(Integer.parseInt(args[i]));
			}

			System.out.println("Sequence Nos.: " + sequenceNumbers);
		}
		return true;
    }

    private void printUsage()
	{
		System.out.println("Usage:");
	    System.out.println("	EMSXDeleteOrderRequest <Sequence No.> [<Sequence No.>...]");
	}
	
}

