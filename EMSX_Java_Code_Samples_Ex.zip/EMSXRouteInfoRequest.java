/* Copyright 2013. Bloomberg Finance L.P.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:  The above
 * copyright notice and this permission notice shall be included in all copies
 * or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
package com.bloomberg.samples;

import com.bloomberglp.blpapi.Element;
import com.bloomberglp.blpapi.Event;
import com.bloomberglp.blpapi.Message;
import com.bloomberglp.blpapi.MessageIterator;
import com.bloomberglp.blpapi.Name;
import com.bloomberglp.blpapi.Session;
import com.bloomberglp.blpapi.SessionOptions;
import com.bloomberglp.blpapi.Request;
import com.bloomberglp.blpapi.Service;
import com.bloomberglp.blpapi.CorrelationID;

public class EMSXRouteInfoRequest {
	
	/* Compile with:-
	 *     javac -cp c:\blp\API\APIv3\JavaAPI\v3.5.1.1\lib\blpapi3.jar com\bloomberg\samples\EMSXRouteInfoRequest.java
	 *     
	 * Run with:-
	 *     java -cp .;c:\blp\API\APIv3\JavaAPI\v3.5.1.1\lib\blpapi3.jar com.bloomberg.samples.EMSXRouteInfoRequest 1437345 1
	 *          
	 */

    private static final Name ERROR_INFO = new Name("ErrorInfo");
    private static final Name ROUTE_INFO = new Name("RouteInfo");

	private String 	d_service;
    private String  d_host;
    private int     d_port;
    
    private String 	emsx_sequence;
    private String 	emsx_route_id;
    
    private CorrelationID requestID;
    
    public static void main(String[] args) throws java.lang.Exception
    {
        System.out.println("Bloomberg - EMSX API Example - EMSXRouteInfoRequest\n");

        EMSXRouteInfoRequest example = new EMSXRouteInfoRequest();
        example.run(args);

        // This sample program will terminate once it has received confirmation that the request
        // has been processed.
    }
    
    public EMSXRouteInfoRequest()
    {
    	
    	// Define the service required, in this case the beta service, 
    	// and the values to be used by the SessionOptions object
    	// to identify IP/port of the back-end process.
    	
    	d_service = "//blp/emapisvc_beta";
    	d_host = "localhost";
        d_port = 8194;

    }

    private void run(String[] args) throws Exception
    {

    	if (!parseCommandLine(args)) return;
    	
    	SessionOptions d_sessionOptions = new SessionOptions();
        d_sessionOptions.setServerHost(d_host);
        d_sessionOptions.setServerPort(d_port);

        Session session = new Session(d_sessionOptions);
        
        if(!session.start()) {
        	System.err.println("Error: failed to start session.");
        	return;
        }
        
        System.out.println("Session started...");
        
        if(!session.openService(d_service)) {
        	session.stop();
        	System.err.println("Error: failed to open service.");
        	return;
        }
        
        Service service = session.getService(d_service);
        System.out.println("Service opened...");

        // Create a GetBrokers request and populate it with the sample ticker 
        // to identify the pricing source
        Request request = service.createRequest("RouteInfo");
        request.set("EMSX_SEQUENCE", emsx_sequence);
        request.set("EMSX_ROUTE_ID",emsx_route_id);
        
        requestID = new CorrelationID(1);
        
        // Submit the request
        System.out.println("Submitting request...");
        session.sendRequest(request, requestID);

    	int timeoutInMilliSeconds = 5000; 

    	Event evt = session.nextEvent(timeoutInMilliSeconds);
    	do
    	{

    		System.out.println("Received Event: " + evt.eventType().toString());
            
            MessageIterator msgIter = evt.messageIterator();
            
            while(msgIter.hasNext())
            {
            	Message msg = msgIter.next();
                System.out.println(msg.toString());
                
                if(evt.eventType()==Event.EventType.RESPONSE && msg.correlationID()==requestID) {
                	
                	System.out.println("Message Type: " + msg.messageType());
                	if(msg.messageType().equals(ERROR_INFO)) {
                		Integer errorCode = msg.getElementAsInt32("ERROR_CODE");
                		String errorMessage = msg.getElementAsString("ERROR_MESSAGE");
                		System.out.println("ERROR CODE: " + errorCode + "\tERROR MESSAGE: " + errorMessage);
                	} else if(msg.messageType().equals(ROUTE_INFO)) {
                		
						String emsx_account = msg.getElementAsString("EMSX_ACCOUNT");
						Integer emsx_amount = msg.getElementAsInt32("EMSX_AMOUNT");
						Double emsx_avg_price = msg.getElementAsFloat64("EMSX_AVG_PRICE");
						Long emsx_blot_date = msg.getElementAsInt64("EMSX_BLOT_DATE");
						Long emsx_blot_seq_num = msg.getElementAsInt64("EMSX_BLOT_SEQ_NUM");
						String emsx_broker = msg.getElementAsString("EMSX_BROKER");
						Double emsx_comm_rate = msg.getElementAsFloat64("EMSX_COMM_RATE");
						String emsx_comm_type = msg.getElementAsString("EMSX_COMM_TYPE");
						Integer emsx_filled = msg.getElementAsInt32("EMSX_FILLED");
						String emsx_hand_instruction = msg.getElementAsString("EMSX_HAND_INSTRUCTION");
						Integer emsx_is_manual_route = msg.getElementAsInt32("EMSX_IS_MANUAL_ROUTE");
						Double emsx_limit_price = msg.getElementAsFloat64("EMSX_LIMIT_PRICE");
						String emsx_loc_broker = msg.getElementAsString("EMSX_LOC_BROKER");
						String emsx_loc_id = msg.getElementAsString("EMSX_LOC_ID");
						Long emsx_lsttr2id0 = msg.getElementAsInt64("EMSX_LSTTR2ID0");
						Long emsx_lsttr2id1 = msg.getElementAsInt64("EMSX_LSTTR2ID1");
						String emsx_order_type = msg.getElementAsString("EMSX_ORDER_TYPE");
						Integer emsx_route_create_date = msg.getElementAsInt32("EMSX_ROUTE_CREATE_DATE");
						Integer emsx_route_create_time = msg.getElementAsInt32("EMSX_ROUTE_CREATE_TIME");
						Integer emsx_route_last_update_date = msg.getElementAsInt32("EMSX_ROUTE_LAST_UPDATE_DATE");
						Integer emsx_route_last_update_time = msg.getElementAsInt32("EMSX_ROUTE_LAST_UPDATE_TIME");
						Integer emsx_settle_date = msg.getElementAsInt32("EMSX_SETTLE_DATE");
						String emsx_status = msg.getElementAsString("EMSX_STATUS");
						Integer emsx_status_id = msg.getElementAsInt32("EMSX_STATUS_ID");
						Double emsx_stop_price = msg.getElementAsFloat64("EMSX_STOP_PRICE");
						String emsx_tif = msg.getElementAsString("EMSX_TIF");
						Double emsx_user_comm_amount = msg.getElementAsFloat64("EMSX_USER_COMM_AMOUNT");
						Double emsx_yield = msg.getElementAsFloat64("EMSX_YIELD");
						
						System.out.println("EMSX_ACCOUNT: " + emsx_account);
						System.out.println("EMSX_AMOUNT: " + emsx_amount);
						System.out.println("EMSX_AVG_PRICE: " + emsx_avg_price);
						System.out.println("EMSX_BLOT_DATE: " + emsx_blot_date);
						System.out.println("EMSX_BLOT_SEQ_NUM: " + emsx_blot_seq_num);
						System.out.println("EMSX_BROKER: " + emsx_broker);
						System.out.println("EMSX_COMM_RATE: " + emsx_comm_rate);
						System.out.println("EMSX_COMM_TYPE: " + emsx_comm_type);
						System.out.println("EMSX_FILLED: " + emsx_filled);
						System.out.println("EMSX_HAND_INSTRUCTION: " + emsx_hand_instruction);
						System.out.println("EMSX_IS_MANUAL_ROUTE: " + emsx_is_manual_route);
						System.out.println("EMSX_LIMIT_PRICE: " + emsx_limit_price);
						System.out.println("EMSX_LOC_BROKER: " + emsx_loc_broker);
						System.out.println("EMSX_LOC_ID: " + emsx_loc_id);
						System.out.println("EMSX_LSTTR2ID0: " + emsx_lsttr2id0);
						System.out.println("EMSX_LSTTR2ID1: " + emsx_lsttr2id1);
						System.out.println("EMSX_ORDER_TYPE: " + emsx_order_type);
						System.out.println("EMSX_ROUTE_CREATE_DATE: " + emsx_route_create_date);
						System.out.println("EMSX_ROUTE_CREATE_TIME: " + emsx_route_create_time);
						System.out.println("EMSX_ROUTE_LAST_UPDATE_DATE: " + emsx_route_last_update_date);
						System.out.println("EMSX_ROUTE_LAST_UPDATE_TIME: " + emsx_route_last_update_time);
						System.out.println("EMSX_SETTLE_DATE: " + emsx_settle_date);
						System.out.println("EMSX_STATUS: " + emsx_status);
						System.out.println("EMSX_STATUS_ID: " + emsx_status_id);
						System.out.println("EMSX_STOP_PRICE: " + emsx_stop_price);
						System.out.println("EMSX_TIF: " + emsx_tif);
						System.out.println("EMSX_USER_COMM_AMOUNT: " + emsx_user_comm_amount);
						System.out.println("EMSX_YIELD: " + emsx_yield);

                	
						if(msg.hasElement("EMSX_STRATEGY_PARAMS")) {
							
							Element params = msg.getElement("EMSX_STRATEGY_PARAMS");
							
							String emsx_strategy_name = params.getElementAsString("EMSX_STRATEGY_NAME");
							
							System.out.println("EMSX_STRATEGY_NAME: " + emsx_strategy_name);
							
							Element fields = msg.getElement("EMSX_STRATEGY_FIELD_NAMES");
							Element values = params.getElement("EMSX_STRATEGY_FIELDS");
							Element indicators = params.getElement("EMSX_STRATEGY_FIELD_INDICATORS");
							
							for(int i = 0; i < fields.numValues(); i++) {
							
								int indicator = indicators.getValueAsElement(i).getElementAsInt32("EMSX_FIELD_INDICATOR");

								if(indicator==0) {
									String field = fields.getValueAsString(i);
									String value = values.getValueAsElement(i).getElementAsString("EMSX_FIELD_DATA");
									System.out.println("Field: " + field + "\tValue: " + value);
								}

							}
							
						}
                	}
                	
                	session.stop();
                	return;
                }
            }
    		
    		evt = session.nextEvent(timeoutInMilliSeconds);

    	} while (evt.eventType() != Event.EventType.TIMEOUT);
    	
    	session.stop();
    }

	private boolean parseCommandLine(String[] args)
    {
		if(args.length < 2 ) {
			printUsage();
			return false;
		} else {
			emsx_sequence = args[0];
			emsx_route_id = args[1];

			System.out.println("Sequence No.: " + emsx_sequence);
			System.out.println("Route ID: " + emsx_route_id + "\n");
		}
		return true;
    }

    private void printUsage()
	{
		System.out.println("Usage:");
	    System.out.println("	EMSXRouteInfoRequest <sequence no> <route ID>\n");
	}
	
}

