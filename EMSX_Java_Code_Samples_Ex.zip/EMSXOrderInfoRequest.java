/* Copyright 2013. Bloomberg Finance L.P.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:  The above
 * copyright notice and this permission notice shall be included in all copies
 * or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
package com.bloomberg.samples;

import com.bloomberglp.blpapi.Event;
import com.bloomberglp.blpapi.Message;
import com.bloomberglp.blpapi.MessageIterator;
import com.bloomberglp.blpapi.Name;
import com.bloomberglp.blpapi.Session;
import com.bloomberglp.blpapi.SessionOptions;
import com.bloomberglp.blpapi.Request;
import com.bloomberglp.blpapi.Service;
import com.bloomberglp.blpapi.CorrelationID;

public class EMSXOrderInfoRequest {
	
	/* Compile with:-
	 *     javac -cp c:\blp\API\APIv3\JavaAPI\v3.5.1.1\lib\blpapi3.jar com\bloomberg\samples\EMSXOrderInfoRequest.java
	 *     
	 * Run with:-
	 *     java -cp .;c:\blp\API\APIv3\JavaAPI\v3.5.1.1\lib\blpapi3.jar com.bloomberg.samples.EMSXOrderInfoRequest 1437345 1
	 *          
	 */

    private static final Name ERROR_INFO = new Name("ErrorInfo");
    private static final Name ORDER_INFO = new Name("OrderInfo");

	private String 	d_service;
    private String  d_host;
    private int     d_port;
    
    private String 	emsx_sequence;
    private int 	emsx_is_aggregated;
    
    private CorrelationID requestID;
    
    public static void main(String[] args) throws java.lang.Exception
    {
        System.out.println("Bloomberg - EMSX API Example - EMSXOrderInfoRequest\n");

        EMSXOrderInfoRequest example = new EMSXOrderInfoRequest();
        example.run(args);

        // This sample program will terminate once it has received confirmation that the request
        // has been processed.
    }
    
    public EMSXOrderInfoRequest()
    {
    	
    	// Define the service required, in this case the beta service, 
    	// and the values to be used by the SessionOptions object
    	// to identify IP/port of the back-end process.
    	
    	d_service = "//blp/emapisvc_beta";
    	d_host = "localhost";
        d_port = 8194;

    }

    private void run(String[] args) throws Exception
    {

    	if (!parseCommandLine(args)) return;
    	
    	SessionOptions d_sessionOptions = new SessionOptions();
        d_sessionOptions.setServerHost(d_host);
        d_sessionOptions.setServerPort(d_port);

        Session session = new Session(d_sessionOptions);
        
        if(!session.start()) {
        	System.err.println("Error: failed to start session.");
        	return;
        }
        
        System.out.println("Session started...");
        
        if(!session.openService(d_service)) {
        	session.stop();
        	System.err.println("Error: failed to open service.");
        	return;
        }
        
        Service service = session.getService(d_service);
        System.out.println("Service opened...");

        // Create a GetBrokers request and populate it with the sample ticker 
        // to identify the pricing source
        Request request = service.createRequest("OrderInfo");
        request.set("EMSX_SEQUENCE", emsx_sequence);
        request.set("EMSX_IS_AGGREGATED",emsx_is_aggregated);
        
        requestID = new CorrelationID(1);
        
        // Submit the request
        System.out.println("Submitting request...");
        session.sendRequest(request, requestID);

    	int timeoutInMilliSeconds = 5000; 

    	Event evt = session.nextEvent(timeoutInMilliSeconds);
    	do
    	{

    		System.out.println("Received Event: " + evt.eventType().toString());
            
            MessageIterator msgIter = evt.messageIterator();
            
            while(msgIter.hasNext())
            {
            	Message msg = msgIter.next();
                System.out.println(msg.toString());
                
                if(evt.eventType()==Event.EventType.RESPONSE && msg.correlationID()==requestID) {
                	
                	System.out.println("Message Type: " + msg.messageType());
                	if(msg.messageType().equals(ERROR_INFO)) {
                		Integer errorCode = msg.getElementAsInt32("ERROR_CODE");
                		String errorMessage = msg.getElementAsString("ERROR_MESSAGE");
                		System.out.println("ERROR CODE: " + errorCode + "\tERROR MESSAGE: " + errorMessage);
                	} else if(msg.messageType().equals(ORDER_INFO)) {
                		
						Integer emsx_amount = msg.getElementAsInt32("EMSX_AMOUNT");
						Double emsx_avg_price = msg.getElementAsFloat64("EMSX_AVG_PRICE");
						String emsx_basket_name = msg.getElementAsString("EMSX_BASKET_NAME");
						String emsx_broker = msg.getElementAsString("EMSX_BROKER");
						String emsx_exchange = msg.getElementAsString("EMSX_EXCHANGE");
						Integer emsx_filled = msg.getElementAsInt32("EMSX_FILLED");
						Integer emsx_flag = msg.getElementAsInt32("EMSX_FLAG");
						Integer emsx_idle_amount = msg.getElementAsInt32("EMSX_IDLE_AMOUNT");
						Double emsx_limit_price = msg.getElementAsFloat64("EMSX_LIMIT_PRICE");
						String emsx_notes = msg.getElementAsString("EMSX_NOTES");
						String emsx_order_create_date = msg.getElementAsString("EMSX_ORDER_CREATE_DATE");
						String emsx_order_create_time = msg.getElementAsString("EMSX_ORDER_CREATE_TIME");
						String emsx_order_type = msg.getElementAsString("EMSX_ORDER_TYPE");
						String emsx_port_mgr = msg.getElementAsString("EMSX_PORT_MGR");
						String emsx_position = msg.getElementAsString("EMSX_POSITION");
						String emsx_side = msg.getElementAsString("EMSX_SIDE");
						String emsx_step_out_broker = msg.getElementAsString("EMSX_STEP_OUT_BROKER");
						Integer emsx_sub_flag = msg.getElementAsInt32("EMSX_SUB_FLAG");
						String emsx_ticker = msg.getElementAsString("EMSX_TICKER");
						String emsx_tif = msg.getElementAsString("EMSX_TIF");
						String emsx_trader = msg.getElementAsString("EMSX_TRADER");
						Long emsx_trader_uuid = msg.getElementAsInt64("EMSX_TRADER_UUID");
						Long emsx_ts_ordnum = msg.getElementAsInt64("EMSX_TS_ORDNUM");
						Integer emsx_working = msg.getElementAsInt32("EMSX_WORKING");
						String emsx_yellow_key = msg.getElementAsString("EMSX_YELLOW_KEY");

						System.out.println("EMSX_AMOUNT: " + emsx_amount);
						System.out.println("EMSX_AVG_PRICE: " + emsx_avg_price);
						System.out.println("EMSX_BASKET_NAME: " + emsx_basket_name);
						System.out.println("EMSX_BROKER: " + emsx_broker);
						System.out.println("EMSX_EXCHANGE: " + emsx_exchange);
						System.out.println("EMSX_FILLED: " + emsx_filled);
						System.out.println("EMSX_FLAG: " + emsx_flag);
						System.out.println("EMSX_IDLE_AMOUNT: " + emsx_idle_amount);
						System.out.println("EMSX_LIMIT_PRICE: " + emsx_limit_price);
						System.out.println("EMSX_NOTES: " + emsx_notes);
						System.out.println("EMSX_ORDER_CREATE_DATE: " + emsx_order_create_date);
						System.out.println("EMSX_ORDER_CREATE_TIME: " + emsx_order_create_time);
						System.out.println("EMSX_ORDER_TYPE: " + emsx_order_type);
						System.out.println("EMSX_PORT_MGR: " + emsx_port_mgr);
						System.out.println("EMSX_POSITION: " + emsx_position);
						System.out.println("EMSX_SIDE: " + emsx_side);
						System.out.println("EMSX_STEP_OUT_BROKER: " + emsx_step_out_broker);
						System.out.println("EMSX_SUB_FLAG: " + emsx_sub_flag);
						System.out.println("EMSX_TICKER: " + emsx_ticker);
						System.out.println("EMSX_TIF: " + emsx_tif);
						System.out.println("EMSX_TRADER: " + emsx_trader);
						System.out.println("EMSX_TRADER_UUID: " + emsx_trader_uuid);
						System.out.println("EMSX_TS_ORDNUM: " + emsx_ts_ordnum);
						System.out.println("EMSX_WORKING: " + emsx_working);
						System.out.println("EMSX_YELLOW_KEY: " + emsx_yellow_key);
                	}
                	
                	session.stop();
                	return;
                }
            }
    		
    		evt = session.nextEvent(timeoutInMilliSeconds);

    	} while (evt.eventType() != Event.EventType.TIMEOUT);
    	
    	session.stop();
    }

	private boolean parseCommandLine(String[] args)
    {
		if(args.length < 2 ) {
			printUsage();
			return false;
		} else {
			emsx_sequence = args[0];
			emsx_is_aggregated = Integer.parseInt(args[1]);

			System.out.println("Sequence No.: " + emsx_sequence);
			System.out.println("Is Aggregated: " + emsx_is_aggregated + "\n");
		}
		return true;
    }

    private void printUsage()
	{
		System.out.println("Usage:");
	    System.out.println("	EMSXOrderInfoRequest <sequence no> <aggregated>\n");
	}
	
}

